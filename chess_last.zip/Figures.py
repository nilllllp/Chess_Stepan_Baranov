from Cell import Cell
from Board import *

class Figure:
    coords : Cell
    color : str
    canMove: list[Cell]

    def __init__(self, coords, color, board):
        self.coords = coords
        self.color = color
        self.board = board
        self.canMove = []

    def __str__(self): pass

    def getColor(self):
        return self.color
    
    def getCoord(self):
        return self.coords
    
    def setCoord(self, coords: Cell):
        self.coords = coords

    def move(self, cell: Cell):
        field: Board = self.board.getBoard()

        figure = self.board.getFigure(cell)
        if isinstance(figure, King):
            if cell in self.getCanMove():
                self.canMove.remove(cell)

        if cell in self.getCanMove():
            prevCoords = self.getCoord()
            field[prevCoords.y][prevCoords.x] = None
            self.setCoord(cell)
            x, y = cell.getCoords()
            field[y][x] = self
            return True
        else:
            print("Невозможно сходить на эту клетку!")
            return False
        
    def getCanMove(self):
        self.calculateCanMove()
        self.canMove = [figure for figure in self.canMove if figure is not None]
        return self.canMove


class Pawn(Figure):
    def __init__(self, coords, color, board):
        super().__init__(coords, color, board)

    def calculateCanMove(self):
        self.canMove = []

        direction = -1 if self.color == "white" else 1
        x, y = self.coords.getCoords()

        start_pos = 6 if self.color == "white" else 1

        double_forward = Cell(x, y + 2 * direction)
        forward = Cell(x, y + direction)

        if self.board.isEmpty(double_forward) and self.board.isEmpty(forward) and start_pos == y:
            self.canMove.append(double_forward)

        if self.board.isEmpty(forward):
            self.canMove.append(forward)

        getRight = Cell(x + direction, y + direction)
        getLeft = Cell(x - direction, y + direction)

        if not self.board.isEmpty(getRight):
            figure = self.board.getFigure(getRight)
            if figure.getColor() != self.color:
                self.canMove.append(getRight)

        if not self.board.isEmpty(getLeft):
            figure = self.board.getFigure(getLeft)
            if figure.getColor() != self.color:
                self.canMove.append(getLeft)

    def __str__(self):
        if self.color == "white":
            return "P"
        else:
            return 'p'
        

class Knight(Figure):
    def __init__(self, coords, color, board):
        super().__init__(coords, color, board)
    
    def calculateCanMove(self):
        self.canMove = []
        x, y = self.coords.getCoords()
        moves = [
            Cell(x + 1, y + 2),
            Cell(x - 1, y + 2),
            Cell(x + 1, y - 2),
            Cell(x - 1, y - 2),
            Cell(x + 2, y + 1),
            Cell(x + 2, y - 1),
            Cell(x - 2, y + 1),
            Cell(x - 2, y - 1)
        ]

        for move in moves:
            if not self.board.isEmpty(move) and move.x is not None and move.y is not None:
                figure = self.board.getFigure(move)
                if figure.getColor() != self.color:
                    self.canMove.append(move)
            else:
                self.canMove.append(move)
        
    def __str__(self):
        if self.color == "white":
            return "N"
        else:
            return 'n'
        
class Bishop(Figure):
    def __init__(self, coords, color, board):
        super().__init__(coords, color, board)

    def calculateCanMove(self):
        self.canMove = []
        x, y = self.coords.getCoords()

        moves = [-1, 1]

        for dx in moves:
            for dy in moves:
                curCell = Cell(x + dx, y + dy)

                while self.board.isEmpty(curCell):
                    if curCell.x is not None and curCell.y is not None:
                        self.canMove.append(curCell) 
                        curCell = Cell(curCell.x + dx, curCell.y + dy)
                    else:
                        curCell = None
                        break

                if curCell and self.board.getFigure(curCell).getColor() != self.color:
                    self.canMove.append(curCell) 

    def __str__(self):
        if self.color == "white":
            return "B"
        else:
            return 'b'
        
class Rook(Figure):
    def __init__(self, coords, color, board):
        super().__init__(coords, color, board)

    def calculateCanMove(self):
        moves = [-1, 1]
        x, y = self.coords.getCoords()

        for dx in moves:
            curCell = Cell(x + dx, y)

            while self.board.isEmpty(curCell):
                if curCell.x is not None and curCell.y is not None:
                    self.canMove.append(curCell) 
                    curCell = Cell(curCell.x + dx, curCell.y)
                else:
                    curCell = None
                    break

            if curCell and self.board.getFigure(curCell).getColor() != self.color:
                self.canMove.append(curCell)

        for dy in moves:
            curCell = Cell(x, y + dy)

            while self.board.isEmpty(curCell):
                if curCell.x is not None and curCell.y is not None:
                    self.canMove.append(curCell) 
                    curCell = Cell(curCell.x, curCell.y + dy)
                else:
                    curCell = None
                    break

            if curCell and self.board.getFigure(curCell).getColor() != self.color:
                self.canMove.append(curCell)


    def __str__(self):
        if self.color == "white":
            return "R"
        else:
            return 'r'
        
class Queen(Figure):
    def __init__(self, coords, color, board):
        super().__init__(coords, color, board)

    def calculateCanMove(self):
        self.canMove = []
        x, y = self.coords.getCoords()

        moves = [-1, 1]

        for dx in moves:
            for dy in moves:
                curCell = Cell(x + dx, y + dy)

                while self.board.isEmpty(curCell):
                    if curCell.x is not None and curCell.y is not None:
                        self.canMove.append(curCell) 
                        curCell = Cell(curCell.x + dx, curCell.y + dy)
                    else:
                        curCell = None
                        break

                if curCell and self.board.getFigure(curCell).getColor() != self.color:
                    self.canMove.append(curCell)

        for dx in moves:
            curCell = Cell(x + dx, y)

            while self.board.isEmpty(curCell):
                if curCell.x is not None and curCell.y is not None:
                    self.canMove.append(curCell) 
                    curCell = Cell(curCell.x + dx, curCell.y)
                else:
                    curCell = None
                    break

            if curCell and self.board.getFigure(curCell).getColor() != self.color:
                self.canMove.append(curCell)

        for dy in moves:
            curCell = Cell(x, y + dy)

            while self.board.isEmpty(curCell):
                if curCell.x is not None and curCell.y is not None:
                    self.canMove.append(curCell) 
                    curCell = Cell(curCell.x, curCell.y + dy)
                else:
                    curCell = None
                    break

            if curCell and self.board.getFigure(curCell).getColor() != self.color:
                self.canMove.append(curCell)

    
    def __str__(self):
        if self.color == "white":
            return "Q"
        else:
            return 'q'
        

class King(Figure):
    def __init__(self, coords, color, board):
        super().__init__(coords, color, board)
    
    def calculateCanMove(self):
        self.canMove = []
        x, y = self.coords.getCoords()
    
        moves = [0, 1, -1]

        for dx in moves:
            for dy in moves:
                curCell = Cell(x + dx, y + dy)

                figure: Figure = self.board.getFigure(curCell)
                if (figure is None or figure.getColor() != self.color) and not isinstance(figure, King):
                    self.canMove.append(curCell)


    def __str__(self):
        if self.color == "white":
            return "K"
        else:
            return 'k'