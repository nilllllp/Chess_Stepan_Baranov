from Board import Board
from Cell import Cell
from Figures import Figure, King, Knight, Pawn

class Game:
    def getPathBetween(attacker: Figure, king: King) -> list[Cell]:
        path = []
        ax, ay, = attacker.getCoord().getCoords()
        kx, ky = king.getCoord().getCoords()

        dx = 1 if ax < kx else -1 if ax > kx else 0
        dy = 1 if ay < ky else -1 if ay > ky else 0
        
        cur_x, cur_y = ax + dx, ay + dy

        while (cur_x, cur_y) != (kx, ky):
            path.append(Cell(cur_x, cur_y))
            cur_x += dx
            cur_y += dy

        return path

    def canBeSaved(board: Board, color: str):
        king: King = board.getKing(color)
        enemyFigures = board.getEnemyFigures(color)
        allyFigures = board.getAllyFigures(color)

        attacking_figures = []
        for figure in enemyFigures:
            if king.getCoord() in figure.getCanMove():
                attacking_figures.append(figure)

        if not attacking_figures:
            print(1)
            return True
        

        if len(attacking_figures) == 1:
            attacker: Figure = attacking_figures[0]
            attacker_pos = attacker.getCoord()

            for figure in allyFigures:
                if attacker_pos in figure.getCanMove():
                    print(2)
                    return True
                
            if not isinstance(attacker, (Knight, Pawn, King)):
                path_to_king = Game.getPathBetween(attacker, king)
                for figure in allyFigures:
                    for move in figure.getCanMove():
                        if move in path_to_king:
                            print(figure)
                            print(move)
                            print(3)
                            return True
        print(4)
        return False


    def move(board: Board, curColor: str):
        figure = None
        try:
            x, y = list(map(int, input().split()))

            if x < 0 or x > 7 or y < 0 or y > 7:
                raise RuntimeError

            figure: Figure = board.getFigure(Cell(x, y))

            if figure.getColor() != curColor or figure is None:
                raise RuntimeError
        except Exception as e:
            print("Введите валидные координаты!")
            return False

        try:
            canMove = figure.getCanMove()

            if not canMove:
                raise RuntimeError
            
            print("Возможные ходы для фигуры:")
            for move in canMove:
                print(move)

            x, y = list(map(int, input("Выберите ход (x, y): ").split()))

            if Cell(x, y) not in canMove:
                raise ValueError

            prev_x, prev_y = figure.getCoord().getCoords()
            prev_figure = board.getFigure(Cell(x, y))

            isMoved = figure.move(Cell(x, y))
            
            if not isMoved:
                raise ValueError

        except RuntimeError as emptyCanMove:
            print("Нет ходов для данной фигуры!")
            return False
        except ValueError as invalidInput:
            print("Введите валидный ход!")
            return False
        
        return True, Cell(prev_x, prev_y), Cell(x, y), prev_figure

    def move_back(board: Board, prev_cell: Cell, cur_cell: Cell, prev_figure: Figure):
        cur_figure = board.getFigure(cur_cell)
        board.setFigure(prev_figure, cur_cell)
        board.setFigure(cur_figure, prev_cell)

    def checkKing(color: str, board: Board):
        CHECK = "check"
        MATE = "mate"
        
        enemyFigures: list[Figure] = board.getEnemyFigures(color)
        king: King = board.getKing(color)

        attacking_figures = []
        for figure in enemyFigures:
            if king.getCoord() in figure.getCanMove():
                attacking_figures.append(figure)

        if not attacking_figures:
            return None
        
        kingMoves = king.getCanMove()
        safeMoves = []

        for move in kingMoves:
            isSafe = True
            for figure in enemyFigures:
                if move in figure.getCanMove():
                    isSafe = False
                    break

            if isSafe:
                safeMoves.append(move)

        if safeMoves:
            return CHECK
        
        if Game.canBeSaved(board, color):
            return CHECK

        return MATE

    def start():
        board = Board()

        count = 0
        while True:
            print(board)
            curColor = None
            if count % 2 == 0:
                print("Ход белых выберите фигуру (x: [0, 3], y: [0, 7]):")
                curColor = "white"
            else:
                print("Ход черных выберите фигуру (x: [0, 3], y: [0, 7]):")
                curColor = "black"
                    
            moved = False
            solved = False
            kingsState = Game.checkKing(curColor, board)
            while kingsState is not None and not solved:
                if kingsState == "mate":
                    print(f"Победили {'белые' if curColor == 'black' else 'черные'}!")
                    exit(0)
                else:
                    print("У вас шах! Сделайте ход, чтобы его избежать")

                moved = Game.move(board, curColor)
                kingsState = Game.checkKing(curColor, board)

                if kingsState is not None:
                    Game.move_back(board, moved[1], moved[2], moved[3])
                else:
                    solved = True

                print(board)
                
            if solved:
                count += 1
                continue

            figure = None
            try:
                x, y = list(map(int, input().split()))

                if x < 0 or x > 7 or y < 0 or y > 7:
                    raise RuntimeError

                figure: Figure = board.getFigure(Cell(x, y))

                if figure.getColor() != curColor or figure is None:
                    raise RuntimeError
            except Exception as e:
                print("Введите валидные координаты!")
                continue

            try:
                canMove = figure.getCanMove()

                if not canMove:
                    raise RuntimeError
                
                print("Возможные ходы для фигуры:")
                for move in canMove:
                    print(move)

                x, y = list(map(int, input("Выберите ход (x, y): ").split()))

                if Cell(x, y) not in canMove:
                    raise ValueError

                isMoved = figure.move(Cell(x, y))
                
                if not isMoved:
                    raise ValueError

            except RuntimeError as emptyCanMove:
                print("Нет ходов для данной фигуры!")
                continue
            except ValueError as invalidInput:
                print("Введите валидный ход!")
                continue

            count += 1