from Game import Game

if __name__ == "__main__":
    Game.start()