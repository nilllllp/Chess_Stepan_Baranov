class Cell:
    x: int
    y: int

    def __init__(self, x, y):        
        if x < 0 or x > 7:
            self.x = None
            self.y = None
        elif y < 0 or y > 7:
            self.y = None
            self.x = None
        else:
            self.x = x
            self.y = y

    def getCoords(self):
        return self.x, self.y
    
    def __eq__(self, value):
        x, y = value.getCoords()

        return self.x == x and self.y == y
    
    def __str__(self):
        return str(self.x) + " " + str(self.y)