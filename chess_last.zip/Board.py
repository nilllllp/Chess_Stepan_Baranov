from Figures import Figure, Pawn, Knight, Bishop, Rook, Queen, King
from Cell import Cell

class Board:
    board: list[Figure]

    def __init__(self):
        self.board = [
            [Rook(Cell(0, 0), "black", self),  Knight(Cell(1, 0), "black", self), Bishop(Cell(2, 0), "black", self), Queen(Cell(3, 0), "black", self), King(Cell(4, 0), "black", self), Bishop(Cell(5, 0), "black", self), Knight(Cell(6, 0), "black", self), Rook(Cell(7, 0), "black", self)],
            [Pawn(Cell(0, 1), "black", self), Pawn(Cell(1, 1), "black", self), Pawn(Cell(2, 1), "black", self), Pawn(Cell(3, 1), "black", self), Pawn(Cell(4, 1), "black", self), Pawn(Cell(5, 1), "black", self), Pawn(Cell(6, 1), "black", self), Pawn(Cell(7, 1), "black", self)],
            [None, None, None, None, None, None, None, None],
            [None, None, None, None, None, None, None, None],
            [None, None, None, None, None, None, None, None],
            [None, None, None, None, None, None, None, None],
            [Pawn(Cell(0, 6), "white", self), Pawn(Cell(1, 6), "white", self), Pawn(Cell(2, 6), "white", self), Pawn(Cell(3, 6), "white", self), Pawn(Cell(4, 6), "white", self), Pawn(Cell(5, 6), "white", self), Pawn(Cell(6, 6), "white", self), Pawn(Cell(7, 6), "white", self)],
            [Rook(Cell(0, 7), "white", self),  Knight(Cell(1, 7), "white", self), Bishop(Cell(2, 7), "white", self), Queen(Cell(3, 7), "white", self), King(Cell(4, 7), "white", self), Bishop(Cell(5, 7), "white", self), Knight(Cell(6, 7), "white", self), Rook(Cell(7, 7), "white", self)]
        ]

    def getFigure(self, cell: Cell):
        x, y = cell.getCoords()
        try:
            return self.board[y][x]
        except Exception as e:
            return None
        
    def setFigure(self, figure: Figure, cell: Cell):
        x, y = cell.getCoords()
        self.board[y][x] = figure

    def isEmpty(self, cell: Cell):
        return self.getFigure(cell) is None
    
    def getBoard(self):
        return self.board
    
    def getKing(self, color):
        for x in range(0, 8):
            for y in range(0, 8):
                figure: Figure = self.getFigure(Cell(x, y))

                if isinstance(figure, King) and figure.getColor() == color:
                    return figure
    
    def getEnemyFigures(self, color: str) -> list[Figure]:
        figures = []
        for x in range(8):
            for y in range(8):
                figure = self.getFigure(Cell(x, y))
                if figure is not None and  figure.getColor() != color:
                    figures.append(figure)
        return figures
    
    def getAllyFigures(self, color: str) -> list[Figure]:
        figures = []
        for x in range(8):
            for y in range(8):
                figure = self.getFigure(Cell(x, y))
                if figure is not None and figure.getColor() == color and not isinstance(figure, King):
                    figures.append(figure)
        return figures
    

    def __str__(self):
        result = "0 1 2 3 4 5 6 7\n"
        count = 0
        for row in self.board:
            for figure in row:
                if figure is not None:
                    result += str(figure) + " "
                else:
                    result += ". "
            result += " " + str(count) + "\n"
            count += 1 

        return result